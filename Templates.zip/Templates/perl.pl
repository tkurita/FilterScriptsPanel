#!/usr/bin/perl
use strict;
use warnings;

while(<>) {
	#add your scripts
}