#!perl -w
use strict;

while(<>) {
	#add your scripts
}